@echo off
setlocal
cd /d "%~dp0"

echo ============================================================
echo   Thunder DeepSeek WeChat Auto-Reply  -  Installer
echo ============================================================
echo.

rem ---------- 1. locate python ----------
set PY=
where python >nul 2>nul && set PY=python
if not defined PY where py >nul 2>nul && set PY=py -3
if not defined PY (
  echo [ERROR] Python not found.
  echo         Install Python 3.11+ from https://www.python.org/downloads/
  echo         IMPORTANT: tick "Add Python to PATH" while installing.
  echo.
  pause
  exit /b 1
)
echo [OK] Python found:
%PY% --version
echo.

rem ---------- 2. virtual environment ----------
set VENV=%USERPROFILE%\AppData\Local\wechatbot\venv
echo [1/4] Creating virtual environment
echo       %VENV%
if not exist "%VENV%\Scripts\python.exe" %PY% -m venv "%VENV%"
if not exist "%VENV%\Scripts\python.exe" (
  echo [ERROR] Could not create the virtual environment.
  pause
  exit /b 1
)
echo       done.
echo.

rem ---------- 3. dependencies ----------
set MIRROR=https://repo.huaweicloud.com/repository/pypi/simple/
echo [2/4] Upgrading pip ...
"%VENV%\Scripts\python.exe" -m pip install --upgrade pip wheel -i %MIRROR% -q

echo [3/4] Installing dependencies (a few minutes) ...
"%VENV%\Scripts\python.exe" -m pip install -r requirements.txt -i %MIRROR% --no-build-isolation
if errorlevel 1 (
  echo.
  echo [WARN] Mirror failed. Retrying with the default PyPI index ...
  "%VENV%\Scripts\python.exe" -m pip install -r requirements.txt --no-build-isolation
)
echo.

rem ---------- 4. config ----------
echo [4/4] Preparing config file ...
if not exist ".env" (
  copy /y ".env.example" ".env" >nul
  echo       Created .env  --  you MUST fill in your DEEPSEEK_API_KEY
) else (
  echo       .env already exists, kept unchanged.
)
echo.

echo ============================================================
echo   Installation finished.
echo.
echo   Next steps:
echo     1. Open .env in Notepad and set:
echo          DEEPSEEK_API_KEY=sk-xxxxxxxxxxxxxxxx
echo     2. Log in to WeChat for Windows (version 4.1.15.x)
echo     3. Double-click run.bat
echo ============================================================
echo.
pause
endlocal
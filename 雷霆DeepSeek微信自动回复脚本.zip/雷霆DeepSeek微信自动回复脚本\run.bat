@echo off
cd /d "%~dp0"
"%USERPROFILE%\AppData\Local\wechatbot\venv\Scripts\python.exe" bot.py %*
echo.
pause

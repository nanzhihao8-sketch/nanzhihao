# 🤖 给 AI 助手的安装提示词

> **用法**：把这个压缩包解压后，把**下面整段提示词**复制粘贴给你的 AI 助手
> （DeepSeek / ChatGPT / Claude / 通义千问……都行），它就会一步步带你装好。

---

## 👇 复制以下内容给 AI

```text
我现在要安装一个叫「雷霆 DeepSeek 微信自动回复脚本」的开源项目（Python 写的），
压缩包已经解压好了，请你**全程协助我安装并启动**。

【项目位置】
解压后的文件夹里应该有这些文件：
  bot.py                主程序
  install.bat           一键安装脚本
  run.bat               启动脚本
  编辑配置.bat           打开配置文件
  .env.example          配置模板
  requirements.txt      依赖清单
  README.md             说明文档
  stickers/             表情包目录

【请你按顺序帮我做这些事】

第 1 步 · 检查环境
  - 确认我电脑上装了 Python 3.11 或更高版本（命令：python --version）
  - 如果没有，告诉我怎么装（要提醒我勾选 Add Python to PATH）
  - 确认微信 PC 版已安装且版本是 4.1.15.x（命令可查：微信 → 设置 → 关于）
  - 确认我是 Windows 系统

第 2 步 · 安装依赖
  - 直接运行 install.bat 就行（它会自动建虚拟环境、装依赖、生成 .env）
  - 如果 install.bat 报错，把错误信息发给我，你帮我分析
  - 常见问题：pip 下载慢 → 换镜像源；缺 wheel → 先装 wheel；
    版本冲突 → 用 --no-build-isolation

第 3 步 · 配置 API Key
  - 让我去 https://platform.deepseek.com/api_keys 申请一个 Key（形如 sk-xxxx）
  - 帮我把 Key 填进 .env 里的 DEEPSEEK_API_KEY=（用记事本就能改）
  - 提醒我：Key 是私密的，不要发给别人、不要上传 GitHub

第 4 步 · 验证
  - 运行 %USERPROFILE%\AppData\Local\wechatbot\venv\Scripts\python.exe bot.py --test-api
  - 如果能正常返回，说明 Key 和网络都没问题

第 5 步 · 启动
  - 确认我微信 PC 版已登录、窗口没有最小化、电脑没有锁屏
  - 运行 run.bat
  - 看到「欢迎使用由【南风知我意】制作的 雷霆DeepSeek微信自动回复脚本」横幅就是成功了
  - 启动时会问「[1]开启 [2]先暂停」，按回车即可（10 秒不操作会自动开启）

第 6 步 · 首次使用引导
  - 告诉我：首次启动会自动学习我的说话风格（约 10~30 秒）
  - 告诉我怎么用控制台：on 开启 / off 暂停 / group off 群聊关闭 / status 状态 / help 帮助
  - 告诉我可以在微信「文件传输助手」里发指令远程控制
  - 提醒我：任何微信自动化都有封号风险，建议先用小号测试

【如果出问题，请重点排查】
  - "未检测到 Weixin.exe" → 微信没开或没登录
  - bot.py 报 ModuleNotFoundError → 依赖没装好，重跑 install.bat
  - 连不上 DeepSeek → 检查 Key 是否正确、余额是否充足、网络是否能访问 api.deepseek.com
  - 回复不像我 → 删掉 persona.txt 重启，会重新学习
  - 一直不回复 → 看控制台是不是被暂停了（输入 on）

请一步一步来，每一步都等我确认后再进行下一步。
我是电脑新手，请用通俗的话解释，不要一次丢太多命令给我。
```

---

## 💡 给 AI 的补充信息（如果它需要）

| 项目 | 值 |
|---|---|
| 虚拟环境位置 | `%USERPROFILE%\AppData\Local\wechatbot\venv` |
| 依赖安装源 | `https://repo.huaweicloud.com/repository/pypi/simple/`（国内快） |
| 核心依赖 | `wechatauto-replica==1.2.4.2`、`httpx` |
| 微信版本要求 | **4.1.15.x**（4.x 系列，其他版本可能不支持） |
| 支持的模型 | `deepseek-chat`（对话）、`deepseek-flash`（看图） |
